(*type var = Var of string;;*)

type tree = Abstr of string * tree | Appl of tree * tree | Var of string;;
